//index.js

Page({
  data: {
    searchValue: '',
    currentTab: 0  , // 当前菜单栏选中的选项索引
    list: [
      {
        imageSrc: '/images/shop1.png',
        title: 'Markless男士羽绒服',
        price: '192元',
        eshop: '京东',
      },
      {
        imageSrc: '/images/shop2.png',
        title: 'Baleno班尼路情侣款卫衣',
        price: '178元',
        eshop: '拼多多'
      },
      {
        imageSrc: '/images/shop3.png',
        title: 'Marden马登男士工作外套',
        price: '177元',
        eshop: '淘宝',
      }
    ]
  },
  onInputChange: function(e) {
    this.setData({
      searchValue: e.detail.value
    })
  },
  onSearch: function() {
    // 在这里编写搜索逻辑
    console.log('搜索关键词：', this.data.searchValue)
  },

 //菜单栏响应
 switchTab: function(e) {
  this.setData({
    currentTab: e.currentTarget.dataset.tab
  })
},  

 //加载图片
 imageError: function (e) {
  console.log('图片加载失败', e)
},
  
//主页商品数据点击响应
shopPage:function(){
  wx.navigateTo({
    url: 'commodity/commodity',
  })
}
})